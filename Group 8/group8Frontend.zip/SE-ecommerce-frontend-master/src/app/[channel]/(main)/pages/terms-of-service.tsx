import React from 'react';

const TermsOfService = () => {
    return (
        <div>
            <h1>Terms of Service</h1>
            <p>These terms govern your use of our website and services...</p>
        </div>
    );
};

export default TermsOfService;