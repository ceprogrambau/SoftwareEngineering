import React from 'react';

const Contact = () => {
    return (
        <div>
            <h1>Contact</h1>
            <p>If you have any questions, feel free to reach out to us...</p>
        </div>
    );
};

export default Contact;