import { Metadata } from "next";

export const metadata: Metadata = {
	title: "Chatbot · PcAndMore",
	description: "Chat with our assistant.",
};
