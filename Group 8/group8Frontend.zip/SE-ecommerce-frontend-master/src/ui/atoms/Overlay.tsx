"use client";

export const Overlay = () => {
	return <div className="fixed inset-0 bg-neutral-500 bg-opacity-75 transition-opacity"></div>;
};
