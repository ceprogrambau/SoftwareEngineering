from .page_create import create_page
from .page_type_create import create_page_type

__all__ = [
    "create_page",
    "create_page_type",
]
