



// // Start auto login immediately
// autoLogin();
let token = localStorage.getItem('token');
let score = 0;
let total = 0;
let currentCase = "";

// If we are on auth.html
if (window.location.pathname.includes('auth.html') || window.location.pathname === "/") {

  async function registerUser() {
    const name = document.getElementById('reg_name').value;
    const email = document.getElementById('reg_email').value;
    const password = document.getElementById('reg_password').value;

    try {
      const response = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
      });

      const data = await response.json();

      if (response.ok) {
        alert('Registration successful! You can now login.');
      } else {
        alert(data.error);
      }
    } catch (err) {
      console.error('Registration error:', err);
    }
  }

  // async function loginUser() {
  //   const email = document.getElementById('login_email').value;
  //   const password = document.getElementById('login_password').value;

  //   try {
  //     const response = await fetch('/api/login', {
  //       method: 'POST',
  //       headers: { 'Content-Type': 'application/json' },
  //       body: JSON.stringify({ email, password })
  //     });

  //     const data = await response.json();

  //     if (response.ok) {
  //       localStorage.setItem('token', data.token);
  //       window.location.href = 'game.html'; // Redirect to game
  //     } else {
  //       alert(data.error);
  //     }
  //   } catch (err) {
  //     console.error('Login error:', err);
  //   }
  // }
  async function loginUser() {
    const email = document.getElementById('login_email').value;
    const password = document.getElementById('login_password').value;
  
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
  
      const data = await response.json();
  
      if (response.ok) {
        localStorage.setItem('token', data.token);
        localStorage.setItem('name', data.name); // 👉 save username here
        window.location.href = 'game.html'; // go to game page
      } else {
        alert(data.error);
      }
    } catch (err) {
      console.error('Login error:', err);
    }
  }
  
  // Bind buttons
  document.getElementById('loginBtn').addEventListener('click', loginUser);
  document.getElementById('registerBtn').addEventListener('click', registerUser);

}

// If we are on game.html
if (window.location.pathname.includes('game.html')) {

  if (!token) {
    window.location.href = 'auth.html';
  }

  async function fetchCase() {
    document.getElementById('caseBox').innerText = 'Loading...';
    const difficulty = document.getElementById('difficulty').value; // Easy / Medium / Hard
    try {
      const response = await fetch('/api/generate-case', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ difficulty })
      });

      const data = await response.json();
      currentCase = data.case;
      document.getElementById('caseBox').innerText = currentCase;
      document.getElementById('resultBox').innerText = '';
    } catch (err) {
      console.error('Fetch case error:', err);
    }
  }

  async function submitAnswer(answer) {
    try {
      const response = await fetch('/api/qualify-answer', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          caseDescription: currentCase,
          userAnswer: answer
        })
      });

      const data = await response.json();

      total++;
      if (data.isCorrect) score++;

      document.getElementById('resultBox').innerHTML = `
        ${data.isCorrect ? '<span style="color:green;">Correct!</span>' : '<span style="color:red;">Wrong!</span>'}
        <br><br>
        Explanation: ${data.explanation}
      `;

      document.getElementById('scoreBox').innerText = `Score: True ${score} | Total ${total}`;

    } catch (err) {
      console.error('Submit answer error:', err);
    }
  }

  function logout() {
    localStorage.removeItem('token');
    window.location.href = 'auth.html';
  }

  // Bind buttons
  document.getElementById('trueBtn').addEventListener('click', () => submitAnswer('True'));
  document.getElementById('falseBtn').addEventListener('click', () => submitAnswer('False'));
  document.getElementById('fetchBtn').addEventListener('click', fetchCase);
  document.getElementById('logoutBtn').addEventListener('click', logout);

}
