
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
const axios = require('axios');
const mysql = require('mysql2/promise');
const cors = require('cors');
const path = require('path'); // <-- Add path

dotenv.config();

const app = express();

// MySQL Connection
const pool = mysql.createPool({
  host: '127.0.0.1',
  user: 'root',
  password: 'hadi',  // ⚡ Change for production
  database: 'cybersecurity_game_awarenessdb'
});

app.use(cors());
app.use(express.json());

// Serve static files
app.use(express.static(path.join(__dirname))); 

// Config
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || '9a8df7b2c6e4f1a3b5d8e2c7a4f6b9d1e3f5a7c8b2d4e6f8a1c3e5d7b9f2e4d6';
const OPENROUTER_API_KEY = "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";  // ⚡ Change for production

// =====================================
// API ROUTES
// =====================================

// Register
app.post('/api/register', async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10); // Hash the password
    const [result] = await pool.query(
      'INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)',
      [name, email, hashedPassword] // Store the hashed password
    );

    res.json({ message: 'User registered successfully!', userId: result.insertId });
  } catch (err) {
    // ... error handling
  }
});


app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    const user = rows[0];
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password_hash); // Compare hashed password
    if (!isMatch) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ id: user.id, name: user.name }, JWT_SECRET, { expiresIn: '1d' });
    res.json({ message: 'Login successful!', token, name: user.name });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error during login.' });
  }
});

// Authentication middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

// Generate case
app.post('/api/generate-case', authenticateToken, async (req, res) => {
  const { difficulty } = req.body;
  let difficultyPrompt = '';

  if (difficulty === 'easy') {
    difficultyPrompt = 'Make it very simple for beginners.';
  } else if (difficulty === 'medium') {
    difficultyPrompt = 'Make it moderately challenging for someone with basic cybersecurity knowledge.';
  } else if (difficulty === 'hard') {
    difficultyPrompt = 'Make it hard and more realistic, targeting advanced cybersecurity knowledge.';
  } else {
    difficultyPrompt = 'Make it simple for general awareness.';
  }

  try {
    const response = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
      model: "meta-llama/llama-4-maverick:free",
      messages: [
        {
          role: "user",
          content: `You are a cybersecurity trainer.
Generate ONE realistic short cybersecurity case (2-3 lines max).
No titles (Scenario, What Happened, etc).
No formatting (*bold*, **stars**, markdown, etc).
The case difficulty is: ${difficultyPrompt}`
        }
      ]
    }, {
      headers: {
        "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
        "HTTP-Referer": "http://localhost",
        "X-Title": "Cybersecurity Awareness Game",
        "Content-Type": "application/json"
      }
    });

    if (!response.data.choices || !response.data.choices[0]) {
      return res.status(503).json({ error: 'OpenRouter service unavailable. Please try again later.' });
    }

    const aiCase = response.data.choices[0].message.content;
    res.json({ case: aiCase });
  } catch (err) {
    console.error('OpenRouter Error:', err.response ? err.response.data : err.message);
    res.status(500).json({ error: 'Failed to generate case' });
  }
});

// Qualify answer
app.post('/api/qualify-answer', authenticateToken, async (req, res) => {
  const { caseDescription, userAnswer } = req.body;

  try {
    const prompt = `
Cybersecurity Case:

"${caseDescription}"

The user judged this case as "${userAnswer}" (True or False).

✅ You MUST answer in exactly this pure JSON format (no extra text):
{
  "isCorrect": true or false,
  "explanation": "short explanation why it is correct or not"
}
✅ Do NOT add any other text before or after the JSON.
`;

    const response = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
      model: "meta-llama/llama-4-maverick:free",
      messages: [
        { role: "user", content: prompt }
      ]
    }, {
      headers: {
        "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost",
        "X-Title": "Cybersecurity Awareness Game"
      }
    });

    let rawReply = response.data.choices[0].message.content.trim();

    // Clean and extract JSON from model
    if (rawReply.includes('```json')) {
      rawReply = rawReply.split('```json')[1].split('```')[0].trim();
    } else if (rawReply.includes('```')) {
      rawReply = rawReply.split('```')[1].split('```')[0].trim();
    }

    const firstCurly = rawReply.indexOf('{');
    const lastCurly = rawReply.lastIndexOf('}');
    if (firstCurly !== -1 && lastCurly !== -1) {
      rawReply = rawReply.substring(firstCurly, lastCurly + 1);
    }

    const aiReply = JSON.parse(rawReply);

    res.json({
      isCorrect: aiReply.isCorrect,
      explanation: aiReply.explanation
    });

  } catch (err) {
    console.error('Error from OpenRouter qualify-answer:', err.response ? err.response.data : err.message);
    res.status(500).json({ error: 'Failed to qualify answer' });
  }
});

// =====================================
// Serve frontend pages
// =====================================

// Default page -> auth.html (login/register)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'auth.html'));
});

// =====================================

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
