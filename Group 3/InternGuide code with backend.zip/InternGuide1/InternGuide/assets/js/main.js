(function ($) {
    "use strict";
  
    jQuery(document).ready(function () {
      // Mobile Navigation
      $('.custom-navbar').on('click', function () {
        $('.main-menu ul').slideToggle(500);
      });
      $(window).on('resize', function () {
        if ($(window).width() > 767) {
          $('.main-menu ul').removeAttr('style');
        }
      });
  
      // Nice Select
      $('select').niceSelect();
  
      // WOW Animations
      new WOW().init();
  
      // Preloader
      $(window).on('load', function () {
        $('.preloader').fadeOut(500);
      });
  
      // --- LOAD INTERNSHIPS ---
      function loadInternships() {
        $.ajax({
          url: 'http://localhost:5000/api/internships',
          method: 'GET',
          success: function (internships) {
            let output = '';
  
            internships.forEach(function (item) {
              output += `
                <div class="col-lg-4 mb-4">
                  <div class="single-job d-lg-flex justify-content-between">
                    <div class="job-text">
                      <h4>${item.Companies}</h4>
                      <ul class="mt-3">
                        <li><i class="fa fa-map-marker"></i> ${item.Country || ''}</li>
                        <li><i class="fa fa-cogs"></i> ${item.JobType || ''} - ${item.ExperienceLevel || ''}</li>
                        <li><i class="fa fa-money"></i> ${item.Salary || 'Negotiable'}</li>
                      </ul>
                    </div>
                    <div class="job-img align-self-center">
                      <img src="assets/images/default.png" alt="Company" style="height:80px;width:80px;">
                    </div>
                  </div>
                  <div class="text-center mt-2">
                    <button class="template-btn" onclick="openApplyPopup('${item.id || item.ID}')">Apply Now</button>
                  </div>
                </div>
              `;
            });
  
            $('#internshipList').html(output);
          },
          error: function () {
            $('#internshipList').html('<p class="text-danger">Failed to load internships.</p>');
          }
        });
      }
  
      loadInternships();
  
      // --- SEARCH ---
      window.searchInternships = function () {
        const keyword = $('#searchInput').val().toLowerCase();
  
        $.ajax({
          url: 'http://localhost:5000/api/internships',
          method: 'GET',
          success: function (internships) {
            let filtered = internships.filter(function (item) {
              return item.Companies && item.Companies.toLowerCase().includes(keyword);
            });
  
            let output = '';
  
            if (filtered.length > 0) {
              filtered.forEach(function (item) {
                output += `
                  <div class="col-lg-4 mb-4">
                    <div class="single-job d-lg-flex justify-content-between">
                      <div class="job-text">
                        <h4>${item.Companies}</h4>
                        <ul class="mt-3">
                          <li><i class="fa fa-map-marker"></i> ${item.Country || ''}</li>
                          <li><i class="fa fa-cogs"></i> ${item.JobType || ''} - ${item.ExperienceLevel || ''}</li>
                          <li><i class="fa fa-money"></i> ${item.Salary || 'Negotiable'}</li>
                        </ul>
                      </div>
                      <div class="job-img align-self-center">
                        <img src="assets/images/default.png" alt="Company" style="height:80px;width:80px;">
                      </div>
                    </div>
                    <div class="text-center mt-2">
                      <button class="template-btn" onclick="openApplyPopup('${item.id || item.ID}')">Apply Now</button>
                    </div>
                  </div>
                `;
              });
            } else {
              output = '<div class="col-lg-12"><p class="text-danger">No internships found.</p></div>';
            }
  
            $('#internshipList').html(output);
          },
          error: function () {
            $('#internshipList').html('<p class="text-danger">Failed to search internships.</p>');
          }
        });
      }
  
    });
  
  })(jQuery);
  