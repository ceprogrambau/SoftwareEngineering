import mysql.connector

print("🛠 Trying to connect...")

try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="tamosalloum",  # Replace if you use another password
        database="softproject"
    )

    if conn.is_connected():
        print("✅ Connected to the database!")

except mysql.connector.Error as err:
    print(f"❌ Connection error: {err}")

finally:
    try:
        if conn.is_connected():
            conn.close()
            print("🔌 Connection closed.")
    except:
        print("⚡ No connection to close.")