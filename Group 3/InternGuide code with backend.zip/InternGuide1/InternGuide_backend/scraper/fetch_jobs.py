# scraper/fetch_jobs.py
import requests
import mysql.connector
from datetime import datetime

def fetch_and_store_jobs():
    params = {
        "engine": "google_jobs",
        "q": "internship software engineering LinkedIn",
        "location": "Beirut, Lebanon",
        "api_key": "90e00261b31647fbfd0167e674d4ca3cddb1cb9e6358a4cd04434affc4fa959b"

    }

    response = requests.get("https://serpapi.com/search.json", params=params)
    
    if response.status_code != 200:
        raise Exception(f"API Error: {response.status_code} {response.text}")

    data = response.json()
    jobs = data.get("jobs_results", [])

    if not jobs:
        print("⚠ No jobs found.")
        return

    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="softproject"
    )
    cursor = conn.cursor()

    for job in jobs:
        company_name = job.get("company_name", "")
        country = job.get("location", "")
        responsibilities = job.get("title", "")
        details = job.get("description", "")
        if details:
            details = details[:400]

        image_path = None
        date_of_listing = datetime.now().date()
        field_of_work_id = 1

        if not company_name or not responsibilities:
            continue

        cursor.execute("""
            INSERT INTO internship_and_jobs_companies
            (Companies, Country, Responsibilities, Details, ImagePath, DateOfListing, FieldOfWorkID)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (company_name, country, responsibilities, details, image_path, date_of_listing, field_of_work_id))

    conn.commit()
    cursor.close()
    conn.close()

    print("✅ Job listings inserted.")

if __name__ == "__main__":
    fetch_and_store_jobs()
