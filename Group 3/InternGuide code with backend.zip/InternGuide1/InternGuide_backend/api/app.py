from flask import Flask, request, jsonify, redirect, url_for
from flask_cors import CORS
import mysql.connector
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)
CORS(app)

# --------- DATABASE CONNECTION ---------
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="tamosalloum",
        database="softproject"
    )

# --------- EMAIL SETTINGS (SMTP) ---------
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
EMAIL_ADDRESS = "YOUR_EMAIL@gmail.com"  # Change this
EMAIL_PASSWORD = "YOUR_APP_PASSWORD"    # Use an app password, NOT your Gmail password!

# --------- ROUTES ---------

# Home Test
@app.route('/')
def home():
    return "Internship Backend Running ✅"

# 1. USER SIGNUP
@app.route('/api/user/signup', methods=['POST'])
def user_signup():
    data = request.form
    connection = get_db_connection()
    cursor = connection.cursor()
    try:
        query = """
            INSERT INTO users (email, password, full_name, dob, gender, major, year, address)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (
            data['email'],
            data['password'],
            data['full_name'],
            data['dob'],
            data['gender'],
            data['major'],
            int(data['year']),
            data['address']
        )
        cursor.execute(query, values)
        connection.commit()
        return jsonify({"message": "User signup successful."}), 200
    except Exception as e:
        return jsonify({"message": str(e)}), 500
    finally:
        cursor.close()
        connection.close()

# 2. USER LOGIN
@app.route('/api/user/login', methods=['POST'])
def user_login():
    data = request.form
    connection = get_db_connection()
    cursor = connection.cursor()
    query = "SELECT * FROM users WHERE email = %s AND password = %s"
    cursor.execute(query, (data['email'], data['password']))
    user = cursor.fetchone()
    cursor.close()
    connection.close()
    if user:
        return jsonify({"message": "Login successful."}), 200
    else:
        return jsonify({"message": "Invalid credentials."}), 401

# 3. RECRUITER SIGNUP
@app.route('/api/recruiter/signup', methods=['POST'])
def recruiter_signup():
    data = request.form
    connection = get_db_connection()
    cursor = connection.cursor()
    try:
        query = """
            INSERT INTO recruiters (company_name, recruiter_name, email, password, contact, address, country, city, about_company)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (
            data['company_name'],
            data['recruiter_name'],
            data['email'],
            data['password'],
            data['contact'],
            data['address'],
            data['country'],
            data['city'],
            data['about_company']
        )
        cursor.execute(query, values)
        connection.commit()
        return jsonify({"message": "Recruiter signup successful."}), 200
    except Exception as e:
        return jsonify({"message": str(e)}), 500
    finally:
        cursor.close()
        connection.close()

# 4. RECRUITER LOGIN
@app.route('/api/recruiter/login', methods=['POST'])
def recruiter_login():
    data = request.form
    connection = get_db_connection()
    cursor = connection.cursor()
    query = "SELECT * FROM recruiters WHERE email = %s AND password = %s"
    cursor.execute(query, (data['email'], data['password']))
    recruiter = cursor.fetchone()
    cursor.close()
    connection.close()
    if recruiter:
        return jsonify({"message": "Login successful."}), 200
    else:
        return jsonify({"message": "Invalid credentials."}), 401

# 5. FETCH INTERNSHIPS
@app.route('/api/internships', methods=['GET'])
def internships():
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    cursor.execute("SELECT * FROM internship_and_jobs_companies")
    internships = cursor.fetchall()
    cursor.close()
    connection.close()
    return jsonify(internships)

# 6. APPLY FOR INTERNSHIP (SENDS EMAIL TO RECRUITER)
@app.route('/api/apply', methods=['POST'])
def apply_internship():
    data = request.form

    # Set up email content
    subject = f"New Internship Application: {data.get('internship_position')}"
    body = f"""
    New Application Received!
    
    Name: {data.get('name')}
    Email: {data.get('email')}
    Message: {data.get('message')}

    Internship: {data.get('internship_position')}
    """

    msg = MIMEMultipart()
    msg['From'] = EMAIL_ADDRESS
    msg['To'] = EMAIL_ADDRESS  # You can dynamically assign recruiter email if you want
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        server.sendmail(EMAIL_ADDRESS, EMAIL_ADDRESS, msg.as_string())
        server.quit()
        return jsonify({"message": "Application sent successfully!"}), 200
    except Exception as e:
        return jsonify({"message": str(e)}), 500

# --------- RUN APP ---------
if __name__ == '__main__':
    app.run(debug=True, port=5000)
