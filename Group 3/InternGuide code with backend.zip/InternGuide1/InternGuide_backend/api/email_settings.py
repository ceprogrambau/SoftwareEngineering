
# email_settings.py

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USERNAME = "tws.tamo@gmail.com"    # <-- Put your Gmail address here
SMTP_PASSWORD = "tamosalloum"         # <-- Put your Gmail App Password here
RECEIVER_EMAIL = "internship@bau.edu.lb"  # <-- This is where contact messages are sent
